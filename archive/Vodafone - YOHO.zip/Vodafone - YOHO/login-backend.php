<?php

$userId = $_POST["userId"];

session_start();
$_SESSION["userId"] = $userId;

header("Location: recommendations.php");

?>